package com.ssafy.product;

public interface Algo {
	void solve();
}
