package com.ssafy.product;

public class DP implements Algo {

	@Override
	public void solve() {
		System.out.println("동적프로그래밍 알고리즘을 풀어요.");
	}

}
