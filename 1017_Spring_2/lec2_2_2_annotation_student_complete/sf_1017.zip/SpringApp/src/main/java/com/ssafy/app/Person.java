package com.ssafy.app;

public interface Person {
	public String getName();
	public void setName(String name);
	public int getAge();
	public void setAge(int age);
	public String getAddr();
	public void setAddr(String addr);
	public String toString();
}
