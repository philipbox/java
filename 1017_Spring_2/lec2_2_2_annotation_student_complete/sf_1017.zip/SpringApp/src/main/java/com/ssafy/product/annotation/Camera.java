package com.ssafy.product.annotation;

public interface Camera {

	public void takePicture();
	
}
