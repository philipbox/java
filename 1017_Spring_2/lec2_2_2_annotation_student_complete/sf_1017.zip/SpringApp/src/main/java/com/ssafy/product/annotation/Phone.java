package com.ssafy.product.annotation;

public interface Phone {
	void powerOn();
	void powerOff();
	void calls();
	void takePicture();
	void studyAlgo();
}
