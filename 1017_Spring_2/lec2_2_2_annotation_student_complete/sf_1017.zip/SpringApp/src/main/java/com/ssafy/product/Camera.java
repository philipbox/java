package com.ssafy.product;

public interface Camera {

	public void takePicture();
	
}
