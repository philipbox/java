package com.ssafy.product;

public interface Phone {
	void powerOn();
	void powerOff();
	void calls();
	void takePicture();
	void studyAlgo();
}
