package com.ssafy.product;

public class Recursive implements Algo {

	@Override
	public void solve() {
		System.out.println("재귀함수를 풀어요.");
	}

}
