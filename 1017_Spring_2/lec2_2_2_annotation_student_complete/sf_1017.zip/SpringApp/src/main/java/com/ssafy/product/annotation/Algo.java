package com.ssafy.product.annotation;

public interface Algo {
	void solve();
}
